class Latte extends AbstractBeverage {
    public Latte()
    {
        super("Latte", 300);
    }

}