class Cappuccino extends AbstractBeverage
{
    public Cappuccino() {
        super("Cappuccino", 100);
    }

}