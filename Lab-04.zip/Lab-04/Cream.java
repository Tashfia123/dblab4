public class Cream extends Condiment
{
    public Cream()
    {
        super("Cream", 30);
    }


}
