public interface Beverage
{
    String getDescription();
    double cost();
    void addCondiment(Condiment condiment);
}
