class Espresso extends AbstractBeverage
{
    public Espresso() {
        super("Espresso", 150);
    }

}
