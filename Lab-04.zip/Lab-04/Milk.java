public class Milk extends Condiment
{
    public Milk() {
        super("Milk", 20);
    }

}