public class Sugar extends Condiment
{
    public Sugar() {
        super("Sugar", 15);
    }

}